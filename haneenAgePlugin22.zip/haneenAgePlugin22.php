<?php
/*
Plugin Name: Registration 
Description: adding a valid positive age attribute

*/

/**
 * Front end registration
 */

add_action( 'register_form', 'crf_registration_form' );
function crf_registration_form() {

	$age = ! empty( $_POST['age_number'] ) ? intval( $_POST['age_number'] ) : '';

	?>
	<p>
		<label for="age_number"><?php esc_html_e( 'age number', 'crf' ) ?><br/>
			<input type="number"
			       min="1"
			       max="100"
			       step="1"
			       id="age_number"
			       name="age_number"
			       value="<?php echo esc_attr( $age ); ?>"
			       class="input"
			/>
		</label>
	</p>
	<?php
}

add_filter( 'registration_errors', 'crf_registration_errors', 10, 3 );
function crf_registration_errors( $errors, $sanitized_user_login, $user_email ) {

	if ( empty( $_POST['age_number'] ) ) {
		$errors->add( 'age_number_error', __( '<strong>ERROR</strong>: Please enter your age number.', 'crf' ) );
	}

	if ( ! empty( $_POST['age_number'] ) && intval( $_POST['age_number'] ) < 1 ) {
		$errors->add( 'age_number_error', __( '<strong>ERROR</strong>: Please enter a valid age', 'crf' ) );
	}

	return $errors;
}

add_action( 'user_register', 'crf_user_register' );
function crf_user_register( $user_id ) {
	if ( ! empty( $_POST['age_number'] ) ) {
		update_user_meta( $user_id, 'age_number', intval( $_POST['age_number'] ) );
	}
}

/**
 * Back end registration
 */

add_action( 'user_new_form', 'crf_admin_registration_form' );
function crf_admin_registration_form( $operation ) {
	if ( 'add-new-user' !== $operation ) {
		// $operation may also be 'add-existing-user'
		return;
	}

	$age = ! empty( $_POST['age_number'] ) ? intval( $_POST['age_number'] ) : '';

	?>
	<h3><?php esc_html_e( 'Personal Information', 'crf' ); ?></h3>

	<table class="form-table">
		<tr>
			<th><label for="age_number"><?php esc_html_e( 'age number', 'crf' ); ?></label> <span class="description"><?php esc_html_e( '(required)', 'crf' ); ?></span></th>
			<td>
				<input type="number"
			       min="1"
			       max="100"
			       step="1"
			       id="age_number"
			       name="age_number"
			       value="<?php echo esc_attr( $age ); ?>"
			       class="regular-text"
				/>
			</td>
		</tr>
	</table>
	<?php
}

add_action( 'user_profile_update_errors', 'crf_user_profile_update_errors', 10, 3 );
function crf_user_profile_update_errors( $errors, $update, $user ) {
	if ( empty( $_POST['age_number'] ) ) {
		$errors->add( 'age_number_error', __( '<strong>ERROR</strong>: Please enter your age number.', 'crf' ) );
	}

	if ( ! empty( $_POST['age_number'] ) && intval( $_POST['age_number'] ) < 1 ) {
		$errors->add( 'age_number_error', __( '<strong>ERROR</strong>: Please enter a valid age', 'crf' ) );
	}
}

add_action( 'edit_user_created_user', 'crf_user_register' );


/**
 * Back end display
 */

add_action( 'show_user_profile', 'crf_show_extra_profile_fields' );
add_action( 'edit_user_profile', 'crf_show_extra_profile_fields' );

function crf_show_extra_profile_fields( $user ) {
	$age = get_the_author_meta( 'age_number', $user->ID );
	?>
	<h3><?php esc_html_e( 'Personal Information', 'crf' ); ?></h3>

	<table class="form-table">
		<tr>
			<th><label for="age_number"><?php esc_html_e( 'age number', 'crf' ); ?></label></th>
			<td>
				<input type="number"
			       min="1"
			       max="100"
			       step="1"
			       id="age_number"
			       name="age_number"
			       value="<?php echo esc_attr( $age ); ?>"
			       class="regular-text"
				/>
			</td>
		</tr>
	</table>
	<?php
}

add_action( 'personal_options_update', 'crf_update_profile_fields' );
add_action( 'edit_user_profile_update', 'crf_update_profile_fields' );

function crf_update_profile_fields( $user_id ) {
	if ( ! current_user_can( 'edit_user', $user_id ) ) {
		return false;
	}

	if ( ! empty( $_POST['age_number'] ) && intval( $_POST['age_number'] ) >= 1 ) {
		update_user_meta( $user_id, 'age_number', intval( $_POST['age_number'] ) );
	}
}